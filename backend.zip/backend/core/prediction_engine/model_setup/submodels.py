from .expert_model import ExpertModel
import tensorflow as tf
from tensorflow.keras.callbacks import EarlyStopping

class AppleExpert:
  def __init__(self, gpu_train: bool = False):
    self.model = ExpertModel()
    self.model.compile()
    self.gpu_train = gpu_train

  def train(self, data, labels, initial_epochs=5, final_epochs=10, **kwargs):
    device = '/GPU:0' if self.gpu_train and tf.config.list_physical_devices('GPU') else '/CPU:0'
    early_stopping = EarlyStopping(monitor='loss', patience=3, restore_best_weights=True)

    # Stage 1: Train on apple-specific data
    with tf.device(device):
      print(f"Training AppleExpert on {device} for Stage 1 (apple data only)")
      apple_data = data[labels == 0]
      apple_labels = labels[labels == 0]
      self.model.fit(apple_data, apple_labels, epochs=initial_epochs, callbacks=[early_stopping], **kwargs)

    # Stage 2: Train on the full multi-class dataset
    with tf.device(device):
      print(f"Training AppleExpert on {device} for Stage 2 (full multi-class data)")
      self.model.fit(data, labels, epochs=final_epochs, callbacks=[early_stopping], **kwargs)

    # Save model after training
    self.save_model("apple_expert.h5")

  def save_model(self, file_path="apple_expert.h5"):
    self.model.save(file_path)

  def load_model(self, file_path="apple_expert.h5"):
    self.model = tf.keras.models.load_model(file_path)


class BananaExpert:
  def __init__(self, gpu_train: bool = False):
    self.model = ExpertModel()
    self.model.compile()
    self.gpu_train = gpu_train

  def train(self, data, labels, initial_epochs=5, final_epochs=10, **kwargs):
    device = '/GPU:0' if self.gpu_train and tf.config.list_physical_devices('GPU') else '/CPU:0'
    early_stopping = EarlyStopping(monitor='loss', patience=3, restore_best_weights=True)

    # Stage 1: Train on banana-specific data
    with tf.device(device):
      print(f"Training BananaExpert on {device} for Stage 1 (banana data only)")
      banana_data = data[labels == 0]
      banana_labels = labels[labels == 0]
      self.model.fit(banana_data, banana_labels, epochs=initial_epochs, callbacks=[early_stopping], **kwargs)

    # Stage 2: Train on the full multi-class dataset
    with tf.device(device):
      print(f"Training BananaExpert on {device} for Stage 2 (full multi-class data)")
      self.model.fit(data, labels, epochs=final_epochs, callbacks=[early_stopping], **kwargs)

    # Save model after training
    self.save_model("banana_expert.h5")

  def save_model(self, file_path="banana_expert.h5"):
    self.model.save(file_path)

  def load_model(self, file_path="banana_expert.h5"):
    self.model = tf.keras.models.load_model(file_path)


class OrangeExpert:
  def __init__(self, gpu_train: bool = False):
    self.model = ExpertModel()
    self.model.compile()
    self.gpu_train = gpu_train

  def train(self, data, labels, initial_epochs=5, final_epochs=10, **kwargs):
    device = '/GPU:0' if self.gpu_train and tf.config.list_physical_devices('GPU') else '/CPU:0'
    early_stopping = EarlyStopping(monitor='loss', patience=3, restore_best_weights=True)

    # Stage 1: Train on orange-specific data
    with tf.device(device):
      print(f"Training OrangeExpert on {device} for Stage 1 (orange data only)")
      orange_data = data[labels == 0]
      orange_labels = labels[labels == 0]
      self.model.fit(orange_data, orange_labels, epochs=initial_epochs, callbacks=[early_stopping], **kwargs)

    # Stage 2: Train on the full multi-class dataset
    with tf.device(device):
      print(f"Training OrangeExpert on {device} for Stage 2 (full multi-class data)")
      self.model.fit(data, labels, epochs=final_epochs, callbacks=[early_stopping], **kwargs)

    # Save model after training
    self.save_model("orange_expert.h5")

  def save_model(self, file_path="orange_expert.h5"):
    self.model.save(file_path)

  def load_model(self, file_path="orange_expert.h5"):
    self.model = tf.keras.models.load_model(file_path)


class MangoExpert:
  def __init__(self, gpu_train: bool = False):
    self.model = ExpertModel()
    self.model.compile()
    self.gpu_train = gpu_train

  def train(self, data, labels, initial_epochs=5, final_epochs=10, **kwargs):
    device = '/GPU:0' if self.gpu_train and tf.config.list_physical_devices('GPU') else '/CPU:0'
    early_stopping = EarlyStopping(monitor='loss', patience=3, restore_best_weights=True)

    # Stage 1: Train on mango-specific data
    with tf.device(device):
      print(f"Training MangoExpert on {device} for Stage 1 (mango data only)")
      mango_data = data[labels == 0]
      mango_labels = labels[labels == 0]
      self.model.fit(mango_data, mango_labels, epochs=initial_epochs, callbacks=[early_stopping], **kwargs)

    # Stage 2: Train on the full multi-class dataset
    with tf.device(device):
      print(f"Training MangoExpert on {device} for Stage 2 (full multi-class data)")
      self.model.fit(data, labels, epochs=final_epochs, callbacks=[early_stopping], **kwargs)

    # Save model after training
    self.save_model("mango_expert.h5")

  def save_model(self, file_path="mango_expert.h5"):
    self.model.save(file_path)

  def load_model(self, file_path="mango_expert.h5"):
    self.model = tf.keras.models.load_model(file_path)
