from backend.utils.data_transform import preprocess_image_with_crop
from backend.core.prediction_engine.model_setup.submodels import AppleExpert
import numpy as np
import os

dataset_paths = {
    "apple": os.path.join(os.path.dirname(__file__), "../../../..", "model/dataset/apples"),
    "banana": os.path.join(os.path.dirname(__file__), "../../../..", "model/dataset/bananas"),
    "orange": os.path.join(os.path.dirname(__file__), "../../../..", "model/dataset/oranges"),
    "mango": os.path.join(os.path.dirname(__file__), "../../../..", "model/dataset/mangos")
}

class_labels = {
    "apple": 0,
    "banana": 1,
    "orange": 2,
    "mango": 3
}

data = []
labels = []

# Load and preprocess data for each fruit type
for fruit, path in dataset_paths.items():
    for filename in os.listdir(path):
        if filename.endswith(".jpg") or filename.endswith(".png"):
            img_path = os.path.join(path, filename)
            img_array = preprocess_image_with_crop(img_path, True)
            data.append(img_array)
            labels.append(class_labels[fruit])  # Append label based on fruit type

# Convert list of img data to numpy array
data = np.array(data)
labels = np.array(labels)

apple_expert = AppleExpert()
apple_expert.train(data, labels)
apple_expert.save_model("apple_expert.h5")